# ursina-tutorials
Hi! here, I'm sharing my tutorial on YouTube in case your code isn't working or something you can reference mines here.
By the way if you havn't checked my youtube channel be sure to check it out!
It's basically a minecracft clone that I try to recreate and at the same time explain the ursina engine.

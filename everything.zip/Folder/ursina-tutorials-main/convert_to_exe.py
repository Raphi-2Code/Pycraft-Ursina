import cx_Freeze
import sys
cx_Freeze.setup(name="MinecraftCreeperEdition",options={"build_exe":{"packages":"ursina"}},executables=[cx_Freeze.Executable("ef.py")],zip_safe=False)
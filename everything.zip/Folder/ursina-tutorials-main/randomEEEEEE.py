from pyautogui import *
from tkinter import *
from tkinter.scrolledtext import *
root=Tk()
ScrolledText(root).pack()
def write_something():typewrite("Hello")
Button(root,command=write_something).pack()
root.mainloop()
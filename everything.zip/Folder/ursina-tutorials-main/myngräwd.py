import math
self=0
def gubi(self,gaugolummmneiiiiiiiiiiiiiiiiiiiiiiiiiii):
        self=math.ceil(self-gaugolummmneiiiiiiiiiiiiiiiiiiiiiiiiiii+math.pi)
        print(self)
gubi(gaugolummmneiiiiiiiiiiiiiiiiiiiiiiiiiii=((self+1)*(self-1)-100),self=self-math.floor(math.pi)-math.ceil(math.pi))